var path = require("path");
daoModule = require("./DAO");
databaseModule = require(path.join(process.cwd(), "modules/database"));


/**
 * ģ����ѯ�û�����
 * 
 * @param  {[type]}   key �ؼ���
 * @param  {Function} cb  �ص�����
 */

module.exports.ClubcountByKey = function (key, cb) {
    db = databaseModule.getDatabase();
    sql = "SELECT count(*) as count FROM club ";
    if (key) {
        sql += " WHERE C_name LIKE ?";
        database.driver.execQuery(
            sql
            , [ "%" + key + "%"], function (err, result) {
                if (err) return cb("��ѯִ�г���");
                cb(null, result[0]["count"]);
            });
    } else {
        
        database.driver.execQuery(sql,function (err, result) {
            if (err) return cb("��ѯִ�г���");
            cb(null, result[0]["count"]);
        });
    }

}




/**
 * ͨ���ؼ��ʲ�ѯ�û�
 * 
 * @param  {[type]}   key    �ؼ���
 * @param  {[type]}   offset 
 * @param  {[type]}   limit  
 * @param  {Function} cb     �ص�����
 */
module.exports.ClubfindByKey = function (key, offset, limit, cb) {
    db = databaseModule.getDatabase();
    sql = "SELECT * FROM club ";

    if (key) {
        sql += " WHERE C_name LIKE ? LIMIT ?,?";
        database.driver.execQuery(
            sql
            , ["%" + key + "%", offset, limit], function (err, gametypes) {
                if (err) return cb("��ѯִ�г���");
                cb(null, gametypes);
            });
    } else {
        sql += "  LIMIT ?,? ";
        database.driver.execQuery(sql, [offset, limit], function (err, gametypes) {
            if (err) return cb("��ѯִ�г���");
            cb(null, gametypes);
        });
    }
}


/**
 * ģ����ѯcommunity����
 * 
 * @param  {[type]}   key �ؼ���
 * @param  {Function} cb  �ص�����
 */

module.exports.CommunitycountByKey = function (key, cb) {
    db = databaseModule.getDatabase();
    sql = "SELECT count(*) as count FROM community ";
    if (key) {
        sql += " WHERE C_name LIKE ?";
        database.driver.execQuery(
            sql
            , ["%" + key + "%"], function (err, result) {
                if (err) return cb("��ѯִ�г���");
                cb(null, result[0]["count"]);
            });
    } else {

        database.driver.execQuery(sql, function (err, result) {
            if (err) return cb("��ѯִ�г���");
            cb(null, result[0]["count"]);
        });
    }

}




/**
 * ͨ���ؼ��ʲ�ѯcommunity
 * 
 * @param  {[type]}   key    �ؼ���
 * @param  {[type]}   offset 
 * @param  {[type]}   limit  
 * @param  {Function} cb     �ص�����
 */
module.exports.CommunityfindByKey = function (key, offset, limit, cb) {
    db = databaseModule.getDatabase();
    sql = "SELECT * FROM community ";

    if (key) {
        sql += " WHERE C_name LIKE ? LIMIT ?,?";
        database.driver.execQuery(
            sql
            , ["%" + key + "%", offset, limit], function (err, gametypes) {
                if (err) return cb("��ѯִ�г���");
                cb(null, gametypes);
            });
    } else {
        sql += "  LIMIT ?,? ";
        database.driver.execQuery(sql, [offset, limit], function (err, gametypes) {
            if (err) return cb("��ѯִ�г���");
            cb(null, gametypes);
        });
    }
}