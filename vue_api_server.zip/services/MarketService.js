var _ = require('lodash');
var path = require("path");
var orm = require("orm");
var dao = require(path.join(process.cwd(), "dao/DAO"));

var Promise = require("bluebird");
var uniqid = require('uniqid');

function doCheckMarketParams(params) {
    return new Promise(function (resolve, reject) {
        var info = {};
        if (params.Selldetail_id) info.Selldetail_id = params.Selldetail_id;

        if (!params.G_id) return reject("ID of Selling Game cannot be blank");
        if (isNaN(parseInt(params.G_id))) return reject("  ID of Selling Game  must be number");

        if (!params.U_id) return reject("ID of Seller cannot be blank");
        if (isNaN(parseInt(params.U_id))) return reject("  ID of Seller must be number");
        if (!params.website_url) return reject("buying website url cannot be blank");

        if (!params.price) return reject("price cannot be blank");

        if (!params.game_condition) return reject("game condition cannot be blank");

        if (!params.location) return reject("seller location cannot be blank");
        if (!params.sending_areas) return reject("seller sending areas cannot be blank");
          

        info.G_id = params.G_id;
        info.U_id = params.U_id;
        info.price = params.price;
        info.game_condition = params.game_condition;
        info.location = params.location;
        info.sending_areas = params.sending_areas;
        info.description = params.description;
        info.website_url = params.website_url;
        
        resolve(info);
    });
}

function doCreateMarket(info) {
    return new Promise(function (resolve, reject) {
        dao.create("MarketModel", _.clone(info), function (err, newMarket) {
            if (err) return reject("Creating New Market fails!");
            info.market = newMarket;
            resolve(info);
        });
    });
}

 
 

function doGetMarket(info) {
    return new Promise(function (resolve, reject) {
        dao.show("MarketModel", info.Selldetail_id, function (err, newMarket) {

            if (err) return reject("Failed to get market details");
            if (!newMarket) return reject("Market ID does not exist");
            info.market = newMarket;
            resolve(info);
        })
    });
}

function doUpdateMarket(info) {
    return new Promise(function (resolve, reject) {
        dao.update("MarketModel", info.Selldetail_id, _.clone(info), function (err, newMarket) {
            if (err) return reject("Update failed");
            info.market = newMarket;
            resolve(info);
        });

    });
}


module.exports.createMarket = function (params, cb) {
    doCheckMarketParams(params)
        .then(doCreateMarket)
        .then(function (info) {
            cb(null, info.market);
        })
        .catch(function (err) {
            cb(err);
        });
}


module.exports.getAllMarkets = function (params, cb) {
    var conditions = {};
    if (!params.pagenum || params.pagenum <= 0) return cb("pagenum Parameter error");
    if (!params.pagesize || params.pagesize <= 0) return cb("pagesize Parameter error");
    conditions["columns"] = {};
    if (params.G_id) {
        conditions["columns"]["G_id"] = params.G_id;
    }

    if (params.U_id) {
        conditions["columns"]["U_id"] = params.U_id;
    }
    if (params.website_url) {
        conditions["columns"]["website_url"] = params.website_url;
    }
    if (params.price) {
        conditions["columns"]["price"] = params.price;
    }
    if (params.game_condition) {
        conditions["columns"]["game_condition"] = params.game_condition;
    }
    if (params.location) {
        conditions["columns"]["location"] = params.location;
    }
    if (params.sending_areas) {
        conditions["columns"]["sending_areas"] = params.sending_areas;
    }
    if (params.description) {
        conditions["columns"]["description"] = params.description;
    }
  
 

    dao.countByConditions("MarketModel", conditions, function (err, count) {
        if (err) return cb(err);
        pagesize = params.pagesize;
        pagenum = params.pagenum;
        pageCount = Math.ceil(count / pagesize);
        offset = (pagenum - 1) * pagesize;
        if (offset >= count) {
            offset = count;
        }
        limit = pagesize;

        // Build conditions
        conditions["offset"] = offset;
        conditions["limit"] = limit;
        // conditions["only"] = 
        conditions["order"] = "price";


        dao.list("MarketModel", conditions, function (err, markets) {
            if (err) return cb(err);
            var resultDta = {};
            resultDta["total"] = count;
            resultDta["pagenum"] = pagenum;
            resultDta["markets"] = _.map(markets, function (market) {
                return market;//_.omit(market,);
            });
            cb(err, resultDta);
        })
    });
}

module.exports.getMarket = function (Selldetail_id, cb) {
    if (!Selldetail_id) return cb("Market ID cannot be blank");
    if (isNaN(parseInt(Selldetail_id))) return cb("Market ID must be number");

    doGetMarket({ "Selldetail_id": Selldetail_id })
        .then(function (info) {
            cb(null, info.market);
        })
        .catch(function (err) {
            cb(err);
        });

}

module.exports.updateMarket = function (Selldetail_id, params, cb) {
    if (!Selldetail_id) return cb("Market ID cannot be blank");
    if (isNaN(parseInt(Selldetail_id))) return cb("Market ID must be number");

    params["Selldetail_id"] = Selldetail_id;
    doCheckMarketParams(params)
        .then(doUpdateMarket)
        .then(function (info) {
            cb(null, info.market);
        })
        .catch(function (err) {
            cb(err);
        });

}

/**
 * ɾ������
 * 
 * @param  {[type]}   id ����ID
 * @param  {Function} cb     �ص�����
 */
module.exports.deleteMarkets = function (id, cb) {
    dao.destroy("MarketModel", id, function (err, post) {
        if (err) return cb("Delete fails");
        cb(null, post);
    });
}