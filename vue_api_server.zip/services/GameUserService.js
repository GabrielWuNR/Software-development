var path = require("path");
var usersDAO = require(path.join(process.cwd(), "dao/UserDAO"));
var Password = require("node-php-password");
var moment = require("moment");


/**
 * Get all users
 * @param  {[type]}   conditions queey filter
 * Unified query criteria
 * conditions
	{
		"query" : Keyword query,
		"pagenum" : Pages,
		"pagesize" : Length per page
	}
 * @param  {Function} cb         Call back
 */
module.exports.getAllUsers = function (conditions, cb) {


    if (!conditions.pagenum) return cb("pagenum illegal parameter");
    if (!conditions.pagesize) return cb("pagesize illegal parameter");


    //Get the number of users by keywords
    usersDAO.countByKey(conditions["query"], function (err, count) {
        key = conditions["query"];
        pagenum = parseInt(conditions["pagenum"]);
        pagesize = parseInt(conditions["pagesize"]);

        pageCount = Math.ceil(count / pagesize);
        offset = (pagenum - 1) * pagesize;
        if (offset >= count) {
            offset = count;
        }
        limit = pagesize;

        usersDAO.findByKey(key, offset, limit, function (err, users) {
            var retUsers = [];
            for (idx in users) {
                var user = users[idx];
                retUsers.push({
                    "user_id": user.user_id,
                    "username": user.username,
                    "user_sex": user.user_sex,
                    "user_tel": user.user_tel,
                    "user_email": user.user_email,
                    "is_active": user.is_active,
                    "birthday": moment(user.birthday).format("YYYY-MM-DD HH:mm:ss"),
                    "U_livingplace": user.U_livingplace,
                    "U_hometown": user.U_hometown,
                    "register_time": moment(user.register_time).format("YYYY-MM-DD HH:mm:ss"),
                    "update_time": moment(user.update_time).format("YYYY-MM-DD HH:mm:ss"),
                    "image_url": user.image_url

                });
            }
            var resultDta = {};
            resultDta["total"] = count;
            resultDta["pagenum"] = pagenum;
            resultDta["users"] = retUsers;
            cb(err, resultDta);
        });
    });
}

/**
 * Create user
 * 
 * @param  {[type]}   user User data set
 * @param  {Function} cb   Call back
 */
module.exports.createUser = function (params, cb) {

    usersDAO.exists(params.username, function (err, isExists) {
        if (err) return cb(err);

        if (isExists) {
            return cb("Username has already exists!");
        }

        usersDAO.create({
            "username": params.username,
            "password": Password.hash(params.password),
            "user_sex": params.user_sex,
            "user_tel": params.user_tel,
            "user_email": params.user_email,
            "is_active": 'Y',
            "birthday": params.birthday,
            "U_livingplace": params.U_livingplace,
            "U_hometown": params.U_hometown,
            "register_time": params.register_time,
            "update_time": params.update_time,
            "image_url": params.image_url

        }, function (err, user) {
            if (err) return cb("Creating fails");
            result = {
                "user_id": user.user_id,   
                "username": user.username,
                "user_sex": user.user_sex,
                "user_tel": user.user_tel,
                "user_email": user.user_email,
                "is_active": 'Y',
                "birthday": moment(user.birthday).format("YYYY-MM-DD HH:mm:ss"),
                "U_livingplace": user.U_livingplace,
                "U_hometown": user.U_hometown,
                "register_time": moment(user.register_time).format("YYYY-MM-DD HH:mm:ss"),
                "update_time": moment(user.update_time).format("YYYY-MM-DD HH:mm:ss"),
                "image_url": user.image_url
            };
            cb(null, result);
        });
    });
}

/**
 * Update user information
 * 
 * @param  {[type]}   params  user information
 * @param  {Function} cb      Call back
 */
module.exports.updateUser = function (params, cb) {
    usersDAO.update(
        {
            "user_id": params.user_id,
            "username": params.username,
            "user_sex": params.user_sex,
            "user_tel": params.user_tel,
            "user_email": params.user_email,
            "is_active": 'Y',
            "birthday": params.birthday,
            "U_livingplace": params.U_livingplace,
            "U_hometown": params.U_hometown,
            "update_time": params.update_time,
            "image_url": params.image_url
        },
        function (err, user) {
            if (err) return cb(err);
            cb(null, {

                "username": user.username,
                "user_sex": user.user_sex,
                "user_tel": user.user_tel,
                "user_email": user.user_email,
                "is_active": 'Y',
                "birthday": moment(user.birthday).format("YYYY-MM-DD HH:mm:ss"),
                "U_livingplace": user.U_livingplace,
                "U_hometown": user.U_hometown,
                "update_time": moment(user.update_time).format("YYYY-MM-DD HH:mm:ss"),
                "image_url": user.image_url
            });
        }
    )
}

/**
 * Get user information by user ID
 * 
 * @param  {[type]}   id   user ID
 * @param  {Function} cb   Call back
 */
module.exports.getUser = function (id, cb) {
    usersDAO.show(id, function (err, user) {
        if (err) return cb(err);
        if (!user) return cb("This user does not exist!");
        cb(
            null,
            {
                "user_id": user.user_id,   
                "username": user.username,
                "user_sex": user.user_sex,
                "user_tel": user.user_tel,
                "user_email": user.user_email,
                "is_active": 'Y',
                "birthday": moment(user.birthday).format("YYYY-MM-DD HH:mm:ss"),
                "U_livingplace": user.U_livingplace,
                "U_hometown": user.U_hometown,
                "register_time": moment(user.register_time).format("YYYY-MM-DD HH:mm:ss"),
                "update_time": moment(user.update_time).format("YYYY-MM-DD HH:mm:ss"),
                "image_url": user.image_url
            }
        );
    });
}

/**
 * Delete by user ID
 * 
 * @param  {[type]}   id  user ID
 * @param  {Function} cb  Call back
 */
module.exports.deleteUser = function (id, cb) {
    usersDAO.destroy(id, function (err) {
        if (err) return cb("Delete fails!");
        cb(null);
    });
}

 
 