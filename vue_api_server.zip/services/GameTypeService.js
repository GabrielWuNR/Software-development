var _ = require('lodash');
var path = require("path");
var dao = require(path.join(process.cwd(),"dao/DAO"));
var GametypeDao = require(path.join(process.cwd(),"dao/Game_categoryDAO"));

/**
 * 获取属性列表
 * 
 * @param  {[type]}   T_id 分类ID
 * @param  {Function} cb     回调函数
 */
module.exports.getTypes = function(T_id,cb) {
    GametypeDao.list(T_id,function(err,attributes) {
		if(err) return cb("Obtain fails");
		cb(null,attributes);
	});
}

/**
 * 创建参数
 * 
 * @param  {[type]}   info 参数信息
 * @param  {Function} cb   回调函数
 */
module.exports.createTypes = function(info,cb) {
    dao.create("GameTypeModel",info,function(err,attribute) {
		if(err) return cb("Create fails");
		cb(null,attribute);
	});
}

/**
 * 更新参数
 * 
 * @param  {[type]}   T_id  分类ID
 * @param  {[type]}   info   更新内容
 * @param  {Function} cb     回调函数
 */
module.exports.updateType = function(T_id,info,cb) {
    dao.update("GameTypeModel", T_id, info, function (err, attribute) {
		if(err) return cb(err);
        cb(null, attribute);
	});
}

/**
 * 删除参数
 * 
 * @param  {[type]}   T_id 参数ID
 * @param  {Function} cb     回调函数
 */
module.exports.deleteType = function (T_id,cb) {
    dao.destroy("GameTypeModel", T_id, function (err, attribute){
		if(err) return cb("删除失败");
        cb(null, attribute);
	});
}

