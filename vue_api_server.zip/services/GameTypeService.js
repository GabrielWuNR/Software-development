var _ = require('lodash');
var path = require("path");
var dao = require(path.join(process.cwd(),"dao/DAO"));
var GametypeDao = require(path.join(process.cwd(),"dao/Game_categoryDAO"));




/**
 * 获取所有管理员
 * @param  {[type]}   conditions 查询条件
 * 查询条件统一规范
 * conditions
	{
		"query" : 关键词查询,
		"pagenum" : 页数,
		"pagesize" : 每页长度
	}
 * @param  {Function} cb         回调函数
 */
module.exports.getAllGameTypes= function (conditions, cb) {


    if (!conditions.pagenum) return cb("pagenum illegal parameter");
    if (!conditions.pagesize) return cb("pagesize illegal parameter");


    // 通过关键词获取游戏类别数量
    GametypeDao.countByKey(conditions["query"], function (err, count) {
        key = conditions["query"];
        pagenum = parseInt(conditions["pagenum"]);
        pagesize = parseInt(conditions["pagesize"]);

        pageCount = Math.ceil(count / pagesize);
        offset = (pagenum - 1) * pagesize;
        if (offset >= count) {
            offset = count;
        }
        limit = pagesize;

        GametypeDao.findByKey(key, offset, limit, function (err, gametypes) {
            var retGameTypes = [];
            for (idx in gametypes) {
                var gametype = gametypes[idx];
           
                retGameTypes.push({
                    "T_id": gametype.T_id,
                    "T_name": gametype.T_name,
                    "T_discription": gametype.T_discription
              
                });
            }
            var resultDta = {};
            resultDta["total"] = count;
            resultDta["pagenum"] = pagenum;
            resultDta["gametypes"] = retGameTypes;
            cb(err, resultDta);
        });
    });
}




/**
 * 获取属性列表
 * 
 * @param  {[type]}   T_id 分类ID
 * @param  {Function} cb     回调函数
 */
module.exports.getTypes = function(T_id,cb) {
    GametypeDao.list(T_id,function(err,attributes) {
		if(err) return cb("Obtain fails");
		cb(null,attributes);
	});
}

/**
 * 创建参数
 * 
 * @param  {[type]}   info 参数信息
 * @param  {Function} cb   回调函数
 */
module.exports.createTypes = function(info,cb) {
    dao.create("GameTypeModel",info,function(err,attribute) {
		if(err) return cb("Create fails");
		cb(null,attribute);
	});
}

/**
 * 更新参数
 * 
 * @param  {[type]}   T_id  分类ID
 * @param  {[type]}   info   更新内容
 * @param  {Function} cb     回调函数
 */
module.exports.updateType = function(T_id,info,cb) {
    dao.update("GameTypeModel", T_id, info, function (err, attribute) {
		if(err) return cb(err);
        cb(null, attribute);
	});
}

/**
 * 删除参数
 * 
 * @param  {[type]}   T_id 参数ID
 * @param  {Function} cb     回调函数
 */
module.exports.deleteType = function (T_id,cb) {
    dao.destroy("GameTypeModel", T_id, function (err, attribute){
		if(err) return cb("删除失败");
        cb(null, attribute);
	});
}

