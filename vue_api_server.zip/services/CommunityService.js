var _ = require('lodash');
var path = require("path");
var dao = require(path.join(process.cwd(), "dao/DAO"));
var countbykeyDAO = require(path.join(process.cwd(), "dao/CountByKeyDAO"));
var moment = require("moment");
/**
 * ��ȡ��������
 * 
 * @param  {Function} cb      �ص�����
 */
module.exports.getAllCommunities = function (conditions, cb) {
    if (!conditions.pagenum || conditions.pagenum <= 0) return cb("pagenum parameter error");
    if (!conditions.pagesize || conditions.pagesize <= 0) return cb("pagesize parameter error");

    // ͨ���ؼ��ʻ�ȡCommunity����
    countbykeyDAO.CommunitycountByKey(conditions["query"], function (err, count) {
        key = conditions["query"];
        pagenum = parseInt(conditions["pagenum"]);
        pagesize = parseInt(conditions["pagesize"]);

        pageCount = Math.ceil(count / pagesize);
        offset = (pagenum - 1) * pagesize;
        if (offset >= count) {
            offset = count;
        }
        limit = pagesize;

        countbykeyDAO.CommunityfindByKey(key, offset, limit, function (err,  communities) {
            var retCommunities = [];
            for (idx in communities) {
                var community = communities[idx];

                retCommunities.push({
                    "C_id": community.C_id,
                    "C_name": community.C_name,
                    "G_id": community.Founder_id,
                    "Commu_del": community.Isdel,
                    "Found_time": moment(community.Found_time).format("YYYY-MM-DD HH:mm:ss"),
                    "Update_time": moment(community.Update_time).format("YYYY-MM-DD HH:mm:ss"),
                    "Description": community.Description

                });
            }
            var resultDta = {};
            resultDta["total"] = count;
            resultDta["pagenum"] = pagenum;
            resultDta["gametypes"] = retCommunities;
            cb(err, resultDta);
        });
    });
}

/**
 * ��ȡ������������
 * 
 * @param  {[type]}   id ����ID
 * @param  {Function} cb �ص�����
 */
module.exports.getCommunityById = function (id, cb) {
    dao.show("CommunityModel", id, function (err, community) {
        if (err) return cb("��ȡ��������ʧ��");
        cb(null, community);
    })
}

/**
 * ��������
 * 
 * @param {[type]}   cat ��������
 * { 
 * C_name  => ��������,
 * G_id => ��ϷID,
 * Found_time => ����ʱ��
 * Update_time => ����ʱ��
* Description => ����
 * }
 * 
 * @param {Function} cb  �ص�����
 */
module.exports.addCommunity = function (community, cb) {
    dao.create("CommunityModel", {
      
        "C_name": community.C_name,
        "G_id": community.G_id,
        "Commu_del": '0',
        "Found_time": community.Found_time,
        "Update_time": community.Update_time,
        " Description": community.Description

    },
        function (err, newCommunity) {
        if (err) return cb("��������ʧ��");
            cb(null, newCommunity);

    });
}

/**
 * ��������
 * 
 * @param  {[type]}   C_id    ����ID
 * @param  {[type]}   params  ������ز���
 * @param  {Function} cb      �ص�����
 */
module.exports.updateCommnunity = function (C_id, params, cb) {
    dao.update("CommunityModel", C_id,
        {
            
            "C_name": params.C_name,
            "G_id": params.G_id,
            "Commu_del": '0', 
            "Update_time": params.Update_time,
            " Description": params.Description
        },
        function (err, newCommunity) {
        if (err) return cb("����ʧ��");
            cb(null, newCommunity);
    });
}

/**
 * ɾ������
 * 
 * @param  {[type]}   cat_id ����ID
 * @param  {Function} cb     �ص�����
 */
module.exports.deleteCommunity = function (C_id, cb) {
    dao.update("CommunityModel", C_id, { "Commu_del": 1 }, function (err, newCommunity) {

        if (err) return cb("Delete failed!");
        cb("Delete succeed!");
    });
}
