var express = require('express');
var router = express.Router();
var path = require("path");
var moment = require("moment");
// ��ȡ��֤ģ��
var authorization = require(path.join(process.cwd(), "/modules/authorization"));

// ͨ����֤ģ���ȡ�������
var CommunityServ = authorization.getService("CommunityService");

// ��ȡ�����б�
router.get("/",
    function (req, res, next) {
        // ������֤
        // if(!req.query.pagenum || req.query.pagenum <= 0) return res.sendResult(null,400,"pagenum ��������");
        // if(!req.query.pagesize || req.query.pagesize <= 0) return res.sendResult(null,400,"pagesize ��������"); 
        next();
    },
    function (req, res, next) {
        var conditions = null;
        if (req.query.pagenum && req.query.pagesize) {
            conditions = {
                "pagenum": req.query.pagenum,
                "pagesize": req.query.pagesize
            };
        }

        CommunityServ.getAllCommunities(conditions, function (err, result) {
            if (err) return res.sendResult(null, 400, "��ȡ�����б�ʧ��");
            res.sendResult(result, 200, "Succeed!");
        })(req, res, next);
    });

// ��������
router.post("/",
    // ������֤
    function (req, res, next) {
        if (!req.body.C_name) {
            return res.sendResult(null, 400, "must provide community name");
        }
        next();
    },
    // ҵ���߼�
    function (req, res, next) {
        CommunityServ.addCommunity({
            "C_name": req.body.C_name,
            "G_id": req.body.G_id,
            "Commu_del":'0',
            "Found_time": req.body.Found_time,
            "Update_time": req.body.Update_time,
            " Description": req.body.Description

        
        }, function (err, result) {
            if (err) return res.sendResult(null, 400, err);
                res.sendResult(result, 201, "Create succeed");
        })(req, res, next);
    }
);

router.get("/:id",
    // ������֤
    function (req, res, next) {
        if (!req.params.id) {
            return res.sendResult(null, 400, "Community ID cannot be blank");
        }
        if (isNaN(parseInt(req.params.id))) return res.sendResult(null, 400, "Community ID must be number");
        next();
    },
    // ����ҵ���߼�
    function (req, res, next) {
        CommunityServ.getCommunityById(req.params.id, function (err, result) {
            if (err) return res.sendResult(null, 400, err);
            res.sendResult(result, 200, "Obtain Succeed!");
        })(req, res, next);
    }
);




// ɾ������
router.delete("/:id",
    // ������֤
    function (req, res, next) {
        if (!req.params.id) {
            return res.sendResult(null, 400, "Community ID cannot be blank");
        }
        if (isNaN(parseInt(req.params.id))) return res.sendResult(null, 400, "Community ID must be number");
        next();
    },
    // ҵ���߼�
    function (req, res, next) {
        CommunityServ.deleteCommunity(req.params.id, function (msg) {
            res.sendResult(null, 200, "Delete succeed!");
        })(req, res, next);
    }
);

// ���·���
router.put("/:id",
    // ������֤
    function (req, res, next) {
        if (!req.params.id) {
            return res.sendResult(null, 400, "Community ID cannot be blank");
        }
        if (isNaN(parseInt(req.params.id))) return res.sendResult(null, 400, "Community ID must be number");
        if (!req.body.C_name || req.body.C_name == "") return res.sendResult(null, 400, "Community name must be number");


        if (!req.body.Update_time || req.body.Update_time == "") return res.sendResult(null, 400, "Update time cannot be blank");

        if (!req.body.G_id) return res.sendResult(null, 400, "Game ID cannot be blank");
        
        if (isNaN(parseInt(req.body.G_id))) return res.sendResult(null, 400, "Game ID must be number");


        next();
    },
    // ҵ���߼�
    function (req, res, next) {
        var params = req.body;
        CommunityServ.updateCommnunity(req.params.id, params, function (err, result) {
            if (err) return res.sendResult(null, 400, err);
            res.sendResult(result, 200, "Update Succeed!");
        })(req, res, next);
    }
);




module.exports = router;