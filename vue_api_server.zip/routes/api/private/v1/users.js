var express = require('express');
var router = express.Router();
var path = require("path");

// Get verification module
var authorization = require(path.join(process.cwd(),"/modules/authorization"));

// Get user management service through authentication module
var mgrServ = authorization.getService("ManagerService");


// Query user list
router.get("/",
	// Verification parameters
	function(req,res,next) {
		// Parameter verification
        if (!req.query.pagenum || req.query.pagenum <= 0) return res.sendResult(null, 400,"pagenum Parameter error");
        if (!req.query.pagesize || req.query.pagesize <= 0) return res.sendResult(null, 400,"pagesize Parameter error"); 
		next();
	},
	// Handling business logic
	function(req,res,next) {
		mgrServ.getAllManagers(
			{
				"query":req.query.query,
				"pagenum":req.query.pagenum,
				"pagesize":req.query.pagesize
			},
			function(err,result){
				if(err) return res.sendResult(null,400,err);
                res.sendResult(result, 200,"Successfully getting the administrator list");
			}
		)(req,res,next);
		
	}
);

// Get user information
router.get("/:id",
    // Parameter verification
	function(req,res,next) {
		if(!req.params.id) {
            return res.sendResult(null, 400,"User ID cannot be empty");
		}
        if (isNaN(parseInt(req.params.id))) return res.sendResult(null, 400,"User ID must be numeric");
		next();
	},
	function(req,res,next) {
		mgrServ.getManager(req.params.id,function(err,manager){
			if(err) return res.sendResult(null,400,err);
            res.sendResult(manager, 200,"Get success");
		})(req,res,next);
	}
);

// Create user
router.post("/",
	// Verification parameters
	function(req,res,next) {
		if(!req.body.username){
            return res.sendResult(null, 400,"Username can not be empty");
		}
		if(!req.body.password) {
            return res.sendResult(null, 400,"password can not be blank");
		}
		if(!req.body.rid) {
			req.body.rid = -1;
			 
		}
		if(isNaN(parseInt(req.body.rid))) req.body.rid = -1; 
		next();
	},
    //  Handling business logic
	function(req,res,next) {
		params = {
			"username":req.body.username,
			"password":req.body.password,
			"mobile":req.body.mobile,
			"email":req.body.email,
			"rid":req.body.rid
		}
		mgrServ.createManager(params,function(err,manager){
			if(err) return res.sendResult(null,400,err);
            res.sendResult(manager, 201,"Created successfully");
		})(req,res,next);
	}
);


// Modify user information
router.put("/:id",
	// Parameter verification
	function(req,res,next) {
		if(!req.params.id) {
            return res.sendResult(null, 400,"User ID cannot be empty");
		}
        if (isNaN(parseInt(req.params.id))) return res.sendResult(null, 400,"User ID must be numeric");
		next();
	},
	// Handling business logic
	function(req,res,next) {
		mgrServ.updateManager(
			{
				"id":req.params.id,
				"mobile":req.body.mobile,
				"email":req.body.email
			},
			function(err,manager) {
				if(err) return res.sendResult(null,400,err);
                res.sendResult(manager, 200, "update completed");
			}
		)(req,res,next);
	}
);

// Delete user information
router.delete("/:id",
	// Verification parameters
	function(req,res,next){
        if (!req.params.id) return res.sendResult(null, 400, "User ID cannot be empty");
        if (isNaN(parseInt(req.params.id))) return res.sendResult(null, 400, "ID must be a number");
        if (req.params.id == 500) return res.sendResult(null, 400, "Not allowed to delete super admin account");
		next();
	},
    // Handling business logic
	function(req,res,next){
		mgrServ.deleteManager(req.params.id,function(err){
			if(err) return res.sendResult(null,400,err);
            return res.sendResult(null, 200, "successfully deleted");
		})(req,res,next);
	}
);

// Assigning user roles
router.put("/:id/role",
    // Parameter verification
	function(req,res,next) {
		if(!req.params.id) {
            return res.sendResult(null, 400,"User ID cannot be empty");
		}
        if (isNaN(parseInt(req.params.id))) return res.sendResult(null, 400,"User ID must be numeric");

        if (req.params.id == 500) return res.sendResult(null, 400,"Modifying the admin account is not allowed");

        if (!req.body.rid) res.sendResult(null, 400, "Permission ID cannot be empty"); 
		next();
	},
	// Handling business logic
	function(req,res,next) {
		mgrServ.setRole(req.params.id,req.body.rid,function(err,manager){
			if(err) return res.sendResult(null,400,err);
            res.sendResult(manager, 200, "Set up role successfully");
		})(req,res,next);
	}
);


router.put("/:id/state/:state",
	// Parameter verification
	function(req,res,next) {
		if(!req.params.id) {
            return res.sendResult(null, 400,"User ID cannot be empty");
		}
        if (isNaN(parseInt(req.params.id))) return res.sendResult(null, 400,"User ID must be numeric");

		// // // if(!req.params.state) {
		// // // 	return res.sendResult(null,400,"状态不能为空");
		// // // }
		// // if(isNaN(parseInt(req.params.state))) return res.sendResult(null,400,"状态必须是数字");
		// if(parseInt(req.params.state) != 0 && parseInt(req.params.state) != 1) return res.sendResult(null,400,"管理状态只能为0或1");

		next();
	},
	// 处理业务逻辑
	function(req,res,next) {
		state = 0
		if(req.params.state && req.params.state == "true") state = 1
		mgrServ.updateMgrState(req.params.id,state,function(err,manager){
			if(err) return res.sendResult(null,400,err);
            res.sendResult(manager, 200,"Set status successfully");
		})(req,res,next);
	}
	)

module.exports = router;