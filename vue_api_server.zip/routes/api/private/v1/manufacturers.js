var express = require('express');
var router = express.Router();
var path = require("path");

// Get verification module
var authorization = require(path.join(process.cwd(), "/modules/authorization"));

// Get manufacturer management service through authentication module
var manuServ = authorization.getService("ManufacturerService");


// Query manufacturer list
router.get("/",
    // Verification parameters
    function (req, res, next) {
        // Parameter verification
        if (!req.query.pagenum || req.query.pagenum <= 0) return res.sendResult(null, 400, "pagenum parameter error");
        if (!req.query.pagesize || req.query.pagesize <= 0) return res.sendResult(null, 400, "pagesize parameter error");
        next();
    },
    // Handling business logic
    function (req, res, next) {
        manuServ.getAllManufacturers(
            {
                "query": req.query.query,
                "pagenum": req.query.pagenum,
                "pagesize": req.query.pagesize
            },
            function (err, result) {
                if (err) return res.sendResult(null, 400, err);
                res.sendResult(result, 200, "Get manufacturer list successfully");
            }
        )(req, res, next);

    }
);

// Get manufacturer information
router.get("/:id",
    // Verification parameters
    function (req, res, next) {
        if (!req.params.id) {
            return res.sendResult(null, 400, "Manufacturer ID cannot be empty");
        }
        if (isNaN(parseInt(req.params.id))) return res.sendResult(null, 400, "Manufacturer ID must be numeric");
        next();
    },
    function (req, res, next) {
        manuServ.getManufacturer(req.params.id, function (err, manufacturer) {
            if (err) return res.sendResult(null, 400, err);
            res.sendResult(manufacturer, 200, "Obtain Succeed!");
        })(req, res, next);
    }
);

// Create manufacturer
router.post("/",
    //  Verification parameters
    function (req, res, next) {
        if (!req.body.M_name) {
            return res.sendResult(null, 400, "Manufacturer name can not be empty");
        }
        if (!req.body.password) {
            return res.sendResult(null, 400, "Password can not be blank");
        }
       
        if (!req.body.M_address) {
            return res.sendResult(null, 400, "Address gender can not be blank");
        }
        if (!req.body.M_contact) {
            return res.sendResult(null, 400, "Contact number can not be blank");
        }
       

        next();
    },
    // Handling business logic
    function (req, res, next) {
        params = {
            "M_name": req.body.M_name,
            "password": req.body.password,
            "M_address": req.body.M_address,
            "M_contact": req.body.M_contact,
            "M_discription": req.body.M_discription 
          
        }


        manuServ.createManufacturer(params, function (err, manufacturer) {
            if (err) return res.sendResult(null, 400, err);
            res.sendResult(manufacturer, 201, "Create succeed");
        })(req, res, next);
    }
);


// Modify manufacturer information
router.put("/:id",
    // Verification parameters
    function (req, res, next) {
        if (!req.params.id) {
            return res.sendResult(null, 400, "Manufacturer ID cannot be empty");
        }
        if (isNaN(parseInt(req.params.id))) return res.sendResult(null, 400, "Manufacturer ID must be numeric");
        next();
    },
    // Handling business logic
    function (req, res, next) {
        manuServ.updateManufacturer(
            {
                "M_id": req.params.id,
                "M_name": req.body.M_name,
                "M_address": req.body.M_address,
                "M_contact": req.body.M_contact,
                "M_discription": req.body.M_discription 
               
            },
            function (err, manufacturer) {
                if (err) return res.sendResult(null, 400, err);
                res.sendResult(manufacturer, 200, "Update Succeed");
            }
        )(req, res, next);
    }
);

// Delete manufacturer information
router.delete("/:id",
    // Verification parameters
    function (req, res, next) {
        if (!req.params.id) return res.sendResult(null, 400, "Manufacturer ID cannot be empty");
        if (isNaN(parseInt(req.params.id))) return res.sendResult(null, 400, "Manufacturer ID must be numeric");

        next();
    },
    // Handling business logic
    function (req, res, next) {
        manuServ.deleteManufacturer(req.params.id, function (err) {
            if (err) return res.sendResult(null, 400, err);
            return res.sendResult(null, 200, "successfully deleted");
        })(req, res, next);
    }
);


module.exports = router;