module.exports = function (db, callback) {
    // �û�ģ��
    db.define("ClubModel", {
        C_id: { type: 'serial', key: true },
        C_name: String,
        Founder_id: Number,
        Isdel: ['0', '1'],
        Found_time: String,
        Update_time: String,
        Description: String
    }, {
            table: "club"
        });
    return callback();
}