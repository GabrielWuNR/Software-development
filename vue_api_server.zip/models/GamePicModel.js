module.exports = function(db,callback){
	// 用户模型
	db.define("GamePicModel",{
		pics_id : {type: 'serial', key: true},
        G_id : Number,
		pics_big : String,
		pics_mid : String,
		pics_sma : String
	},{
            table: "Game_display_images"
	});
	return callback();
}