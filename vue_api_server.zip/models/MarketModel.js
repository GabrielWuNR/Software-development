module.exports = function (db, callback) {
    // Market Model
    db.define("MarketModel", {
        Selldetail_id: { type: 'serial', key: true },
        G_id: Number,
        U_id: Number,
        price: Number,
        game_condition: String,
        location: String,
        sending_areas: String,
        website_url: String,
        description: String
    }, {
            table: "market"
        });
    return callback();
}