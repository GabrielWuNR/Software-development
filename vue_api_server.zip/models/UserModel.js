module.exports = function (db, callback) {
    // Front end User Model
    db.define("UserModel", {
        user_id: { type: 'serial', key: true },
        username: String,
        password: String,
        user_sex: String,
        user_tel: String,
        user_email: String,
        is_active: ['Y', 'N'],
        birthday: String,
        U_livingplace: String,
        U_hometown: String,
        register_time: String,
        update_time: String,
        image_url: String
    }, {
            table: "user"
        });
    return callback();
}