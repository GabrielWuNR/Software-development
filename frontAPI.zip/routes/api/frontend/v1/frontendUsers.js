var express = require('express');
var router = express.Router();
var path = require("path");

// Get verification module
var authorization = require(path.join(process.cwd(), "/modules/authorization"));

// Get user management service through authentication module
var userServ = authorization.getService("GameUserService");


// Query user list
router.get("/",
    // Verification parameters
    function (req, res, next) {
        // Parameter verification
        if (!req.query.pagenum || req.query.pagenum <= 0) return res.sendResult(null, 400, "pagenum parameter error");
        if (!req.query.pagesize || req.query.pagesize <= 0) return res.sendResult(null, 400, "pagesize parameter error");
        next();
    },
    // Handling business logic
    function (req, res, next) {
        userServ.getAllUsers(
            {
                "query": req.query.query,
                "pagenum": req.query.pagenum,
                "pagesize": req.query.pagesize
            },
            function (err, result) {
                if (err) return res.sendResult(null, 400, err);
                res.sendResult(result, 200, "Get user list successfully");
            }
        )(req, res, next);

    }
);

// Get user information
router.get("/:id",
    // Verification parameters
    function (req, res, next) {
        if (!req.params.id) {
            return res.sendResult(null, 400, "User ID cannot be empty");
        }
        if (isNaN(parseInt(req.params.id))) return res.sendResult(null, 400, "User ID must be numeric");
        next();
    },
    function (req, res, next) {
        userServ.getUser(req.params.id, function (err, user) {
            if (err) return res.sendResult(null, 400, err);
            res.sendResult(user, 200, "Obtain Succeed!");
        })(req, res, next);
    }
);

// Create User
router.post("/",
    //  Verification parameters
    function (req, res, next) {
        if (!req.body.username) {
            return res.sendResult(null, 400, "Username can not be empty");
        }
        if (!req.body.password) {
            return res.sendResult(null, 400, "Password can not be blank");
        }
        if (!req.body.password) {
            return res.sendResult(null, 400, "Password can not be blank");
        }
        if (!req.body.user_sex) {
            return res.sendResult(null, 400, "User gender can not be blank");
        }
        if (!req.body.user_email) {
            return res.sendResult(null, 400, "User email can not be blank");
        }
        if (!req.body.register_time) {
            return res.sendResult(null, 400, "User register time can not be blank");
        }

        next();
    },
    // Handling business logic
    function (req, res, next) {
        params = {
            "username": req.body.username,
            "password": req.body.password,
            "user_sex": req.body.user_sex,
            "user_tel": req.body.user_tel,
            "user_email": req.body.user_email,
            "is_active": 'Y',
            "birthday": req.body.birthday,
            "U_livingplace": req.body.U_livingplace,
            "U_hometown": req.body.U_hometown,
            "register_time": req.body.register_time,
            "update_time": req.body.update_time,
            "image_url": req.body.image_url
        }


        userServ.createUser(params, function (err, user) {
            if (err) return res.sendResult(null, 400, err);
            res.sendResult(user, 201, "Create succeed");
        })(req, res, next);
    }
);


// Modify user information
router.put("/:id",
    // Verification parameters
    function (req, res, next) {
        if (!req.params.id) {
            return res.sendResult(null, 400, "User ID cannot be empty");
        }
        if (isNaN(parseInt(req.params.id))) return res.sendResult(null, 400, "User ID must be numeric");
        next();
    },
    // Handling business logic
    function (req, res, next) {
        userServ.updateUser(
            {
                "user_id": req.params.id,
                "username": req.body.username,
                "user_sex": req.body.user_sex,
                "user_tel": req.body.user_tel,
                "user_email": req.body.user_email,
                "birthday": req.body.birthday,
                "U_livingplace": req.body.U_livingplace,
                "U_hometown": req.body.U_hometown,
                "update_time": req.body.update_time,
                "image_url": req.body.image_url
            },
            function (err, user) {
                if (err) return res.sendResult(null, 400, err);
                res.sendResult(user, 200, "Update Succeed");
            }
        )(req, res, next);
    }
);

// Delete user information
router.delete("/:id",
    // Verification parameters
    function (req, res, next) {
        if (!req.params.id) return res.sendResult(null, 400, "User ID cannot be empty");
        if (isNaN(parseInt(req.params.id))) return res.sendResult(null, 400, "User ID must be numeric");
    
        next();
    },
    // Handling business logic
    function (req, res, next) {
        userServ.deleteUser(req.params.id, function (err) {
            if (err) return res.sendResult(null, 400, err);
            return res.sendResult(null, 200, "successfully deleted");
        })(req, res, next);
    }
);
 

 

module.exports = router;