var express = require('express');
var router = express.Router();
var path = require("path");

// 获取验证模块
var authorization = require(path.join(process.cwd(),"/modules/authorization"));

// 通过验证模块获取分类管理
var gameServ = authorization.getService("GameService");

// 商品列表
router.get("/",
	// 验证参数
	function(req,res,next) {
		// 参数验证
		if(!req.query.pagenum || req.query.pagenum <= 0) return res.sendResult(null,400,"pagenum 参数错误");
		if(!req.query.pagesize || req.query.pagesize <= 0) return res.sendResult(null,400,"pagesize 参数错误"); 
		next();
	},
	// 业务逻辑
	function(req,res,next) {
		var conditions = {
			"pagenum" : req.query.pagenum,
			"pagesize" : req.query.pagesize
		};

		if(req.query.query) {
			conditions["query"] = req.query.query;
		}
        gameServ.getAllGames(
			conditions,
			function(err,result){
				if(err) return res.sendResult(null,400,err);
				res.sendResult(result,200,"获取成功");
			}
		)(req,res,next);
	}
);

// 添加商品
router.post("/",
	// 参数验证
	function(req,res,next) {
		next();
	},
	// 业务逻辑
	function(req,res,next) {
		var params = req.body;
		gameServ.createGame(params,function(err,newGame){
			if(err) return res.sendResult(null,400,err);
            res.sendResult(newGame, 201,"创建游戏成功");
		})(req,res,next);
	}
);

// 更新游戏  可能有bug
router.put("/:id",
	// 参数验证
	function(req,res,next) {
		if(!req.params.id) {
			return res.sendResult(null,400,"游戏ID不能为空");
		}
        if (isNaN(parseInt(req.params.id))) return res.sendResult(null, 400,"游戏ID必须是数字");
		next();
	},
	// 业务逻辑
	function(req,res,next) {
        var params = req.body;
        params.G_id = req.params.id;
        gameServ.updateGame(req.params.id,params,function(err,newGame){
			if(err) return res.sendResult(null,400,err);
            res.sendResult(newGame, 200,"更新游戏成功");
		})(req,res,next);
	}
);

// 获取游戏详情
router.get("/:id",
	// 参数验证
	function(req,res,next) {
		if(!req.params.id) {
            return res.sendResult(null, 400,"游戏ID不能为空");
		}
        if (isNaN(parseInt(req.params.id))) return res.sendResult(null, 400,"游戏ID必须是数字");
		next();
	},
	// 业务逻辑
	function(req,res,next) {
		gameServ.getGameById(req.params.id,function(err,game){
			if(err) return res.sendResult(null,400,err);
            return res.sendResult(game,200,"获取成功");
		})(req,res,next);
	}
);



// 删除游戏
router.delete("/:id",
	// 参数验证
	function(req,res,next) {
		if(!req.params.id) {
			return res.sendResult(null,400,"游戏ID不能为空");
		}
		if(isNaN(parseInt(req.params.id))) return res.sendResult(null,400,"游戏ID必须是数字");
		next();
	},
	// 业务逻辑
	function(req,res,next) {
		gameServ.deleteGame(req.params.id,function(err){
			if(err)
				return res.sendResult(null,400,"删除失败");
			else
				return res.sendResult(null,200,"删除成功");
		})(req,res,next);
	}
);

// 更新游戏的图片
router.put("/:id/pics",
	// 参数验证
	function(req,res,next) {
		if(!req.params.id) {
            return res.sendResult(null, 400,"游戏ID不能为空");
		}
        if (isNaN(parseInt(req.params.id))) return res.sendResult(null, 400,"游戏ID必须是数字");
		next();
	},
	// 业务逻辑
	function(req,res,next) {
		
		gameServ.updateGamePics(
			req.params.id,
			req.body,
			function(err,game){
				if(err) return res.sendResult(null,400,err);
				res.sendResult(game,200,"更新成功");
			}
		)(req,res,next);
	}
);


module.exports = router;
