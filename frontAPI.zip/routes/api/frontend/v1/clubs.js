var express = require('express');
var router = express.Router();
var path = require("path");

// Get authentication module
var authorization = require(path.join(process.cwd(), "/modules/authorization"));

// ͨ����֤ģ���ȡ������Ϣ����
var ClubServ = authorization.getService("ClubService");

// ��ȡclub�б�
router.get("/",
    function (req, res, next) {
        // ������֤
        // if(!req.query.pagenum || req.query.pagenum <= 0) return res.sendResult(null,400,"pagenum ��������");
        // if(!req.query.pagesize || req.query.pagesize <= 0) return res.sendResult(null,400,"pagesize ��������"); 
        next();
    },
    function (req, res, next) {
        var conditions = null;
        if (req.query.pagenum && req.query.pagesize) {
            conditions = {
                "pagenum": req.query.pagenum,
                "pagesize": req.query.pagesize
            };
        }

        ClubServ.getAllClubs(conditions, function (err, result) {
            if (err) return res.sendResult(null, 400, "Obtain clubs list fail!");
            res.sendResult(result, 200, "Obtain succeed!");
        })(req, res, next);
    });

// ����club
router.post("/",
    // ������֤
    function (req, res, next) {
        if (!req.body.C_name) {
            return res.sendResult(null, 400, "must provide club name");
        }
        next();
    },
    // ҵ���߼�
    function (req, res, next) {
        ClubServ.addClub({
            "C_name": req.body.C_name,
            "Founder_id": req.body.Founder_id,
            "Isdel": '0',
            "Found_time": req.body.Found_time,
            "Update_time": req.body.Update_time,
            " Description": req.body.Description


        }, function (err, result) {
            if (err) return res.sendResult(null, 400, err);
            res.sendResult(result, 201, "Succeed creating");
        })(req, res, next);
    }
);

router.get("/:id",
    // ������֤
    function (req, res, next) {
        if (!req.params.id) {
            return res.sendResult(null, 400, "club ID cannot be empty");
        }
        if (isNaN(parseInt(req.params.id))) return res.sendResult(null, 400, "club ID must be numeric");
        next();
    },
    // ����ҵ���߼�
    function (req, res, next) {
        ClubServ.getClubyById(req.params.id, function (err, result) {
            if (err) return res.sendResult(null, 400, err);
            res.sendResult(result, 200, "Get success");
        })(req, res, next);
    }
);


// Query club posts list req.params.id
router.get("/:id/posts",
    // Verification parameters
    function (req, res, next) {
        // Parameter verification
        if (!req.query.pagenum || req.query.pagenum <= 0) return res.sendResult(null, 400, "pagenum parameter error");
        if (!req.query.pagesize || req.query.pagesize <= 0) return res.sendResult(null, 400, "pagesize parameter error");
        next();
    },
    // Handling business logic
    function (req, res, next) {
        ClubServ.getAllClubPost(
            {
                "pt_id": 2,
                "post_belong": req.params.id,
                "query": req.query.query,
                "pagenum": req.query.pagenum,
                "pagesize": req.query.pagesize
            },
            function (err, result) {
                if (err) return res.sendResult(null, 400, err);
                res.sendResult(result, 200, "Get club post list successfully");
            }
        )(req, res, next);

    }
);



// ɾ��club
router.delete("/:id",
    // ������֤
    function (req, res, next) {
        if (!req.params.id) {
            return res.sendResult(null, 400, "club ID cannot be empty");
        }
        if (isNaN(parseInt(req.params.id))) return res.sendResult(null, 400, "club ID must be numeric");
        next();
    },
    // ҵ���߼�
    function (req, res, next) {
        ClubServ.deleteClub(req.params.id, function (msg) {
            res.sendResult(null, 200, msg);
        })(req, res, next);
    }
);

// ����club
router.put("/:id",
    // ������֤
    function (req, res, next) {
        if (!req.params.id) {
            return res.sendResult(null, 400, "club��ID����Ϊ��");
        }
        if (isNaN(parseInt(req.params.id))) return res.sendResult(null, 400, "club��ID����������");
        if (!req.body.C_name || req.body.C_name == "") return res.sendResult(null, 400, "club���Ʋ���Ϊ��");


         
         

        if (!req.body.Update_time || req.body.Update_time == "") return res.sendResult(null, 400, "����ʱ�䲻��Ϊ��");

        if (!req.body.Founder_id) return res.sendResult(null, 400, "�����û�ID����Ϊ��");
     
        next();
    },
    // ҵ���߼�
    function (req, res, next) {
        var params = req.body;
        ClubServ.updateClub(req.params.id, params, function (err, result) {
            if (err) return res.sendResult(null, 400, err);
            res.sendResult(result, 200, "update completed");
        })(req, res, next);
    }
);


// Query club posts list req.params.id
router.get("/:id/test/posts",
    // Verification parameters
    function (req, res, next) {
        // Parameter verification
        if (!req.query.pagenum || req.query.pagenum <= 0) return res.sendResult(null, 400, "pagenum parameter error");
        if (!req.query.pagesize || req.query.pagesize <= 0) return res.sendResult(null, 400, "pagesize parameter error");
        next();
    },
    // Handling business logic
    function (req, res, next) {
        ClubServ.getAllClubPostcount(
            {
                "pt_id": 2,
                "post_belong": req.params.id,
                "query": req.query.query,
                "pagenum": req.query.pagenum,
                "pagesize": req.query.pagesize
            },
            function (err, result) {
                if (err) return res.sendResult(null, 400, err);
                res.sendResult(result, 200, "Get club post list successfully");
            }
        )(req, res, next);

    }
);


module.exports = router;