module.exports = function (db, callback) {
    // Front end Manufacturer Model
    db.define("ManufacturerModel", {
        M_id: { type: 'serial', key: true },
        M_name: String,
        password: String,
        M_address: String,
        M_contact: String,
        M_discription: String
    }, {
            table: "manufacturer"
        });
    return callback();
}